--------------------------------------
  How to upgrade the asset to URP
--------------------------------------
To upgrade the asset to URP just open the "Pipeline Upgrade" folder and click in the package to replace the materials and shaders with the URP ones. It may also be needed to check the HDR checkbox in the render pipeline asset if the colors of the effects aren't correct.
--------------------------------------
               Contact
--------------------------------------
For support, don't hesitate to send me an email to contact@travisgameassets.com.