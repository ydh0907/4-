using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;
using GM;
using System;

namespace HB
{
    public class PlayerMovement : NetworkBehaviour
    {
        public static bool canMove = true;

        public PlayerMovementData Data;

        #region COMPONENTS
        public Rigidbody RB { get; private set; }
        public Animator Animator { get; private set; }
        #endregion

        private PlayerDamageble PlayerDamageble;
        private DrinkDamageble DrinkDamageble;

        #region STATE PARAMETERS
        private const float LERP_AMOUNT = 1f;
        private const float SPAWN_TIME = 5f;
        #endregion

        public bool IsJumping { get; private set; }
        public bool IsRushing { get; private set; }
        public float CurrentTime { get; private set; }

        #region INPUT PARAMETERS
        [HideInInspector] public Vector3 _moveInput;
        #endregion

        #region CHECK PARAMETERS
        [Header("Checks")]
        [SerializeField] private Transform _groundCheckPoint;
        [Tooltip("groundCheck�� ũ��� Player�� ũ�⺸�� �ణ ���� ���� ����.")]
        [SerializeField] private Vector3 _groundCheckSize;
        [SerializeField] private float _maxDistance;
        #endregion

        #region LAYERS & TAGS
        [Header("Layers & Tags")]
        [SerializeField] private LayerMask _groundLayer;
        #endregion

        [SerializeField] Transform follow;

        Vector3 temppos = Vector3.zero;

        public override void OnNetworkSpawn()
        {
            RB = GetComponent<Rigidbody>();

            PlayerDamageble = GetComponent<PlayerDamageble>();
            SetGravityScale(Data.gravityScale);
        }

        private void FixedUpdate()
        {
            if (!IsOwner) return;

            if (!Animator || !DrinkDamageble)
            {
                return;
            }

            if (CanRun())
            {
                Run(LERP_AMOUNT);
            }
            // rush
            if (CanRush())
            {
                Rush();
            }

            if (RB.velocity.y < 0)
            {
                // ���Ͻ� �߷°� ���� 
                SetGravityScale(Data.gravityScale * Data.fallGravityMult);
            }
            else
            {
                // �⺻ �߷°�
                SetGravityScale(Data.gravityScale);
            }
        }

        private void Update()
        {
            if (!canMove) return;

            if (!Animator || !DrinkDamageble)
            {
                Animator = GetComponentInChildren<Animator>();
                DrinkDamageble = GetComponentInChildren<DrinkDamageble>();

                return;
            }

            if (!IsOwner)
            {
                SetAnimation();
                return;
            }


            #region INPUT HANDLER
            float x = Input.GetAxisRaw("Horizontal");
            float z = Input.GetAxisRaw("Vertical");
            _moveInput.x = x;
            _moveInput.z = z;

            // jump
            if (CanJump() && Input.GetKeyDown(KeyCode.Space))
            {
                IsJumping = true;
                Animator.SetTrigger("IsJumping");

                Jump();
            }
            #endregion

            #region POLAR BEAR SPAWN
            // *����
            // ���� �ð��� 2��, �ϱذ� ��ȯ �ð��� 5�ʶ� �Ͽ��� ��
            // Player�� 3�� ���� ������ �ִٰ� �����Ͽ���
            // ���ǵ� Ÿ�ǵ� �������� ���� �ð��� �� 5�� �̴� �ϱذ��� ��ȯ�Ѵ�.

            if (RB.velocity != Vector3.zero)
            {
                CurrentTime = 0;
            }
            else
            {
                CurrentTime += Time.deltaTime;
                if (CurrentTime >= SPAWN_TIME)
                {
                    SpawnPolarBear.Instance.CallPolarBear(transform);
                    CurrentTime = 0;
                }
            }
            #endregion
        }

        private void SetAnimation()
        {
            Animator.SetFloat("AnimationSpeed", (transform.position - temppos).magnitude * (1 / Time.deltaTime));
            temppos = transform.position;

            if (!Physics.Raycast(transform.position, Vector3.down, 0.5f, _groundLayer))
            {
                Animator.SetTrigger("IsJumping");
            }
        }

        public void SetGravityScale(float scale)
        {
            RB.AddForce(Vector3.down * scale);
        }

        // Movement Methods
        #region RUN METHODS
        private void Run(float lerpAmount)
        {
            Vector3 moveDirection = _moveInput.normalized;
            float targetSpeed;

            if (IsRushing)
                targetSpeed = moveDirection.magnitude * Data.rushMaxSpeed;
            else
                targetSpeed = moveDirection.magnitude * Data.runMaxSpeed;

            targetSpeed = Mathf.Lerp(RB.velocity.magnitude, targetSpeed, lerpAmount);
            Animator.SetFloat("AnimationSpeed", targetSpeed);

            if (CanRun())
            {
                Vector3 velo = (follow.right * moveDirection.x + follow.forward * moveDirection.z).normalized * targetSpeed;
                RB.velocity = new Vector3(velo.x, RB.velocity.y, velo.z);
            }

            // Rotation
            if (moveDirection != Vector3.zero)
            {
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.LookRotation(new Vector3(RB.velocity.x, 0, RB.velocity.z)), Data.rotationFactorPerFrame * Time.deltaTime);
            }
        }
        #endregion

        #region Rush METHODS
        private void Rush()
        {
            DrinkDamageble.StartRush();
        }
        #endregion

        #region JUMP METHODS
        private void Jump()
        {
            float force = Data.jumpForce;
            if (RB.velocity.y < 0)
                force -= RB.velocity.y;

            RB.AddForce(Vector2.up * force, ForceMode.Impulse);
        }
        #endregion

        private bool CanRun()
        {
            if (!PlayerDamageble.IsGroggying)
                return true;
            else
            {
                RB.velocity = new Vector3(0f, RB.velocity.y, 0f);
                return false;
            }
        }

        private bool CanRush()
        {
            if (Input.GetKey(KeyCode.LeftShift))
            {
                IsRushing = true;
                return true;
            }
            else
            {
                IsRushing = false;
                return false;
            }
        }

        private bool CanJump()
        {
            if (IsGounded() && !PlayerDamageble.IsGroggying)
                return true;
            else
            {
                return false;
            }
        }

        private bool IsGounded()
        {
            // Ground Check
            if (Physics.BoxCast(_groundCheckPoint.position, _groundCheckSize * 0.5f, -_groundCheckPoint.up, _groundCheckPoint.rotation, _maxDistance, _groundLayer))
            {
                IsJumping = false;
                return true;
            }
            else
            {
                return false;
            }
        }

        #region EDITOR METHODS
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.green;
            Gizmos.DrawCube(_groundCheckPoint.position - _groundCheckPoint.up * _maxDistance, _groundCheckSize);
        }
        #endregion
    }
}
