using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace HB
{
    public class HealthBar : MonoBehaviour
    {
        [Header("������ ������")]
        [SerializeField]
        private Transform _barTransform;

        public void HandleHealthChanged(float oldHealth, float newHealth, float ratio)
        {
            ratio = Mathf.Clamp01(ratio);
            _barTransform.localScale = new Vector3(ratio, 1, 1);
        }
    }
}
