using UnityEngine;

namespace PJH
{
    public partial class Player
    {
        public void ControlAnimatorRootMotion()
        {
            if (!this.enabled) return;

            // if (UseRootMotion)
            //     MoveCharacter(_moveDirection);
        }
    }
}