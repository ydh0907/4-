﻿namespace Packets
{
    public enum PacketID : ushort
    {
        C_ReRoadingPacket, 
        S_ReRoadingPacket,  
        S_RoomCreatePacket, 
        C_RoomCreatePacket,
        S_RoomDeletePacket, 
        C_RoomDeletePacket, 
    }
}
